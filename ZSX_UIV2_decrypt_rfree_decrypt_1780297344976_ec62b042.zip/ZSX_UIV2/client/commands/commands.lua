RegisterCommand('remove_nui_storage', function()
    NUI.SendMessage('REMOVE_STORAGE_FULLY', {})
end)

-- RegisterCommand('open_map', function()
--     NUI.SetRoutePath('/blank')
--     ActivateFrontendMenu(GetHashKey('FE_MENU_VERSION_MP_PAUSE'), 0, -1)
--     if not IsPauseMenuActive() or IsPauseMenuRestarting() then 
--         while not IsPauseMenuActive() or IsPauseMenuRestarting() do
--             Wait(0)
--         end
--     end
--     Citizen.CreateThread(function()
--         Wait(50)
--         PauseMenuceptionGoDeeper(0)
--         PauseMenuceptionTheKick()
--     end)
--     DisplayRadar(false, true)
--     StartAudioScene('DEATH_SCENE')
--     while true do
--         Citizen.Wait(0)
--         if IsControlJustPressed(0, 200) or IsControlJustPressed(0, 177) or IsControlJustPressed(0,202) then
--             SetFrontendActive(0)
--             break
--         end
--     end

--     StopAudioScene('DEATH_SCENE')
--     NUI.SetRoutePath('/')
-- end)

-- RegisterKeyMapping('open_map', 'Opens map', 'KEYBOARD', 'P')

if not Config.Chat.Use then return debugPrint('Removing commands.') end
RegisterCommand('me', function(src, args, _)
    local argsOutput = _Lib.ConvertArgumentsToString(args) -- converting arguments to text ((args[n]))
    Chat.CreateMessage('ME', argsOutput, '#c94b5b', true, 10.0)
end)

RegisterCommand('do', function(src, args, _)
    local argsOutput = _Lib.ConvertArgumentsToString(args) -- converting arguments to text ((args[n]))
    Chat.CreateMessage('DO', argsOutput, '#1A1A1A', true, 10.0)
end)

RegisterCommand('twt', function(src, args, _)
    local argsOutput = _Lib.ConvertArgumentsToString(args) -- converting arguments to text ((args[n]))
    Chat.CreateMessage('fab fa-twitter', argsOutput, '#64A6FD', false, false)
end)

LocalOutOfCharacter = function(message)
    if not message or message == '' then return end
    Chat.CreateMessage('fas fa-globe', message, '#0c0c0cd9', false, 10.0)
end
