local L0_1, L1_1, L2_1
L0_1 = {}
L0_1.state = false
L0_1.forced = false
L0_1.isForced = false
L1_1 = _G
function L2_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2
  L0_1.state = A0_2
  L0_1.forced = A1_2
  L0_1.isForced = A2_2
  L3_2 = Minimap
  L3_2.Visible = A0_2
  if A2_2 then
    L3_2 = _DisplayRadar
    L4_2 = A0_2
    L3_2(L4_2)
  else
    L3_2 = Citizen
    L3_2 = L3_2.CreateThread
    function L4_2()
      local L0_3, L1_3, L2_3
      L0_3 = Minimap
      L0_3 = L0_3.Prepared
      if L0_3 then
        L0_3 = NUI
        L0_3 = L0_3.Loaded
        if L0_3 then
          goto lbl_21
        end
      end
      while true do
        L0_3 = Minimap
        L0_3 = L0_3.Prepared
        if L0_3 then
          L0_3 = NUI
          L0_3 = L0_3.Loaded
          if L0_3 then
            break
          end
        end
        L0_3 = Wait
        L1_3 = 0
        L0_3(L1_3)
      end
      ::lbl_21::
      L0_3 = Minimap
      L0_3 = L0_3.Animate
      L1_3 = A0_2
      L2_3 = A1_2
      L0_3(L1_3, L2_3)
      L0_3 = A1_2
      if not L0_3 then
        L0_3 = Wait
        L1_3 = 400
        L0_3(L1_3)
      end
      L0_3 = Storage
      L0_3 = L0_3.GetCurrentScreen
      L0_3 = L0_3()
      L1_3 = L0_1.state
      if false == L1_3 then
        L1_3 = A0_2
        if L1_3 then
          goto lbl_46
        end
      end
      if "pausemenu" == L0_3 then
        L1_3 = A0_2
        ::lbl_46::
        if L1_3 then
          L1_3 = false
          A0_2 = L1_3
          L1_3 = debugPrint
          L2_3 = "[^2MINIMAP^7] Early exit. State has changed."
          L1_3(L2_3)
        end
      end
      L1_3 = _DisplayRadar
      L2_3 = A0_2
      L1_3(L2_3)
    end
    L3_2(L4_2)
  end
  L3_2 = Workers
  L3_2 = L3_2.Minimap
  L3_2 = L3_2.OnVisibilityStateChange
  L4_2 = A0_2
  L3_2(L4_2)
end
L1_1.DisplayRadar = L2_1
