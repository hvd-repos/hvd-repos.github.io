local L0_1, L1_1, L2_1, L3_1, L4_1
L0_1 = {}
PauseMenu = L0_1
L0_1 = PauseMenu
L0_1.Cam = false
L0_1 = PauseMenu
L0_1.IsActive = false
L0_1 = PauseMenu
function L1_1()
  local L0_2, L1_2, L2_2
  L0_2 = Config
  L0_2 = L0_2.UI
  L0_2 = L0_2.UsePauseMenu
  if not L0_2 then
    return
  end
  L0_2 = PauseMenu
  L0_2 = L0_2.Cam
  if false ~= L0_2 then
    return
  end
  L0_2 = LocalPlayer
  L0_2 = L0_2.state
  L0_2 = L0_2.UI_UserData
  if not L0_2 then
    return
  end
  L0_2 = NUI
  L0_2 = L0_2.SendMessage
  L1_2 = "SHOW_PAUSEMENU"
  L2_2 = {}
  L2_2.state = true
  L0_2(L1_2, L2_2)
  L0_2 = SetNuiFocus
  L1_2 = true
  L2_2 = true
  L0_2(L1_2, L2_2)
  L0_2 = DisplayRadar
  L1_2 = false
  L2_2 = true
  L0_2(L1_2, L2_2)
end
L0_1.Init = L1_1
L0_1 = Citizen
L0_1 = L0_1.CreateThread
function L1_1()
  local L0_2, L1_2, L2_2, L3_2
  L0_2 = LocalPlayer
  L0_2 = L0_2.state
  L1_2 = L0_2
  L0_2 = L0_2.set
  L2_2 = "UI_DataLoaded"
  L3_2 = false
  L0_2(L1_2, L2_2, L3_2)
end
L0_1(L1_1)
L0_1 = PauseMenu
function L1_1()
  local L0_2, L1_2, L2_2
  L0_2 = NUI
  L0_2 = L0_2.SendMessage
  L1_2 = "SHOW_PAUSEMENU"
  L2_2 = {}
  L2_2.state = false
  L0_2(L1_2, L2_2)
  L0_2 = SetNuiFocus
  L1_2 = false
  L2_2 = false
  L0_2(L1_2, L2_2)
end
L0_1.Disable = L1_1
L0_1 = RegisterCommand
L1_1 = "switchhud"
function L2_1()
  local L0_2, L1_2
  L0_2 = NUI
  L0_2 = L0_2.SetUIVisible
  L1_2 = false
  L0_2(L1_2)
end
L0_1(L1_1, L2_1)
L0_1 = AddStateBagChangeHandler
L1_1 = "UI_UserData"
L2_1 = nil
function L3_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2
  L3_2 = "player:%s"
  L4_2 = L3_2
  L3_2 = L3_2.format
  L5_2 = GetPlayerServerId
  L6_2 = PlayerId
  L6_2 = L6_2()
  L5_2, L6_2 = L5_2(L6_2)
  L3_2 = L3_2(L4_2, L5_2, L6_2)
  if A0_2 ~= L3_2 then
    return
  end
  if "UI_UserData" == A1_2 then
    L3_2 = NUI
    L3_2 = L3_2.Loaded
    if not L3_2 then
      L3_2 = debugPrint
      L4_2 = "[^2UI_DATA^7] Awaiting for NUI to be loaded [/]"
      L3_2(L4_2)
      while true do
        L3_2 = NUI
        L3_2 = L3_2.Loaded
        if L3_2 then
          break
        end
        L3_2 = Wait
        L4_2 = 0
        L3_2(L4_2)
      end
      L3_2 = debugPrint
      L4_2 = "[^2UI_DATA^7] NUI loaded, continue"
      L3_2(L4_2)
    end
    L3_2 = debugPrint
    L4_2 = "[^2UI_DATA^7] Attempting to load player data [/]"
    L3_2(L4_2)
    L3_2 = debugPrint
    L4_2 = "[^2UI_DATA^7] Setting player data."
    L3_2(L4_2)
    L3_2 = NUI
    L3_2 = L3_2.SendMessage
    L4_2 = "SET_PLAYER_DATA"
    L5_2 = A2_2
    L3_2(L4_2, L5_2)
    L3_2 = debugPrint
    L4_2 = "[^2UI_DATA^7] Returning values back to the UI."
    L3_2(L4_2)
    L3_2 = PauseMenu
    L3_2 = L3_2.Update
    L4_2 = A2_2
    return L3_2(L4_2)
  end
end
L0_1(L1_1, L2_1, L3_1)
L0_1 = RegisterNetEvent
L1_1 = "ZSX_UIV2:Client:LoadPlayer"
function L2_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2
  L0_2 = Config
  L0_2 = L0_2.HandleUIVisibilityOnBaseEvents
  if L0_2 then
    L0_2 = {}
    L1_2 = debugPrint
    L2_2 = "[^2UI_DATA_LOAD^7] Applying visibility on UI."
    L1_2(L2_2)
    L1_2 = LocalPlayer
    L1_2 = L1_2.state
    L1_2 = L1_2.UI_DataLoaded
    if not L1_2 then
      L1_2 = LocalPlayer
      L1_2 = L1_2.state
      L2_2 = L1_2
      L1_2 = L1_2.set
      L3_2 = "UI_DataLoaded"
      L4_2 = true
      L1_2(L2_2, L3_2, L4_2)
      L1_2 = NUI
      L1_2 = L1_2.SetDataLoadedStatus
      L2_2 = true
      L1_2(L2_2)
      L1_2 = NUI
      L1_2 = L1_2.SetUIVisible
      L2_2 = true
      L1_2(L2_2)
      L1_2 = GetResourceState
      L2_2 = "MugShotBase64"
      L1_2 = L1_2(L2_2)
      if "started" == L1_2 then
        L1_2 = Config
        L1_2 = L1_2.UI
        L1_2 = L1_2.UseMugShotBase64
        if L1_2 then
          L1_2 = debugPrint
          L2_2 = "[^2UI_DATA_LOAD^7] [MUGSHOT] Mugshot available, creating instance [/]"
          L1_2(L2_2)
          L1_2 = promise
          L2_2 = L1_2
          L1_2 = L1_2.new
          L1_2 = L1_2(L2_2)
          L2_2 = Citizen
          L2_2 = L2_2.CreateThread
          function L3_2()
            local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3
            L0_3 = GetGameTimer
            L0_3 = L0_3()
            L1_3 = L0_3
            L2_3 = L1_3 + 3000
            L3_3 = exports
            L3_3 = L3_3.MugShotBase64
            L4_3 = L3_3
            L3_3 = L3_3.GetMugShotBase64
            L5_3 = PlayerPedId
            L5_3 = L5_3()
            L3_3 = L3_3(L4_3, L5_3)
            L4_3 = debugPrint
            L5_3 = "[^2UI_DATA_LOAD^7] [MUGSHOT] Awaiting for the instance to be created [/]"
            L4_3(L5_3)
            while L0_3 < L2_3 and not L3_3 do
              L4_3 = GetGameTimer
              L4_3 = L4_3()
              L0_3 = L4_3
              L4_3 = Wait
              L5_3 = 10
              L4_3(L5_3)
            end
            L4_3 = debugPrint
            L5_3 = "[^2UI_DATA_LOAD^7] [MUGSHOT] Instance created, continue."
            L4_3(L5_3)
            if L3_3 then
              L4_3 = debugPrint
              L5_3 = "[^2UI_DATA_LOAD^7] [MUGSHOT] Applied mugshot."
              L4_3(L5_3)
              L0_2.mugshot = L3_3
            end
            L4_3 = debugPrint
            L5_3 = "[^2UI_DATA_LOAD^7] [MUGSHOT] Resolving promise."
            L4_3(L5_3)
            L4_3 = L1_2
            L5_3 = L4_3
            L4_3 = L4_3.resolve
            L4_3(L5_3)
          end
          L2_2(L3_2)
          L2_2 = Citizen
          L2_2 = L2_2.Await
          L3_2 = L1_2
          L2_2(L3_2)
          L2_2 = debugPrint
          L3_2 = "[^2UI_DATA_LOAD^7] [MUGSHOT] Promise resolved."
          L2_2(L3_2)
        end
      end
      L1_2 = Config
      L1_2 = L1_2.PersistentMinimap
      if L1_2 then
        L1_2 = debugPrint
        L2_2 = "[^2UI_DATA_LOAD^7] Preparing Minimap [/]"
        L1_2(L2_2)
        while true do
          L1_2 = NUI
          L1_2 = L1_2.Loaded
          if L1_2 then
            break
          end
          L1_2 = Minimap
          L1_2 = L1_2.Prepared
          if L1_2 then
            break
          end
          L1_2 = Storage
          L1_2 = L1_2.CurrentScreen
          L1_2 = not L1_2
          if "game" ~= L1_2 then
            break
          end
          L1_2 = Wait
          L2_2 = 0
          L1_2(L2_2)
        end
        L1_2 = debugPrint
        L2_2 = "[^2UI_DATA_LOAD^7] Minimap prepared."
        L1_2(L2_2)
        L1_2 = DisplayRadar
        L2_2 = true
        L1_2(L2_2)
        L1_2 = Config
        L1_2 = L1_2.PersistentStreetLabel
        if L1_2 then
          L1_2 = StreetLabel
          L1_2 = L1_2.SetVisible
          L2_2 = true
          L1_2(L2_2)
          L1_2 = Threads
          L1_2 = L1_2.Vehicles
          L1_2 = L1_2.StreetLabelUse
          if not L1_2 then
            L1_2 = Threads
            L1_2 = L1_2.Vehicles
            L1_2 = L1_2.StreetLabel
            L1_2()
          end
        end
      end
    end
  end
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "ZSX_UIV2:Client:UnloadPlayer"
L0_1(L1_1)
L0_1 = AddEventHandler
L1_1 = "ZSX_UIV2:Client:UnloadPlayer"
function L2_1()
  local L0_2, L1_2, L2_2, L3_2
  L0_2 = debugPrint
  L1_2 = "[^2UI_DATA^7] Unloading player data."
  L0_2(L1_2)
  L0_2 = LocalPlayer
  L0_2 = L0_2.state
  L0_2 = L0_2.UI_DataLoaded
  if L0_2 then
    L0_2 = LocalPlayer
    L0_2 = L0_2.state
    L1_2 = L0_2
    L0_2 = L0_2.set
    L2_2 = "UI_DataLoaded"
    L3_2 = false
    L0_2(L1_2, L2_2, L3_2)
    L0_2 = NUI
    L0_2 = L0_2.SetDataLoadedStatus
    L1_2 = false
    L0_2(L1_2)
    L0_2 = NUI
    L0_2 = L0_2.SetUIVisible
    L1_2 = false
    L0_2(L1_2)
  end
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "ZSX_UIV2:Client:PlayerInitialized"
L0_1(L1_1)
L0_1 = AddEventHandler
L1_1 = "ZSX_UIV2:Client:PlayerInitialized"
function L2_1()
  local L0_2, L1_2
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "ZSX_UI:Player:State:Set"
L0_1(L1_1)
L0_1 = AddEventHandler
L1_1 = "ZSX_UI:Player:State:Set"
function L2_1(A0_2)
  local L1_2, L2_2
  L1_2 = PauseMenu
  L1_2 = L1_2.Update
  L2_2 = A0_2
  L1_2(L2_2)
end
L0_1(L1_1, L2_1)
L0_1 = PauseMenu
function L1_1(A0_2)
  local L1_2, L2_2, L3_2
  L1_2 = NUI
  L1_2 = L1_2.SendMessage
  L2_2 = "UPDATE_PAUSEMENU"
  L3_2 = {}
  L3_2.userData = A0_2
  L1_2(L2_2, L3_2)
end
L0_1.Update = L1_1
L0_1 = PauseMenu
L0_1.LastRecordedCamState = false
L0_1 = PauseMenu
function L1_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2
  L0_2 = Threads
  L0_2 = L0_2.Players
  L0_2 = L0_2.Data
  L0_2 = L0_2.ped
  L1_2 = IsPedInAnyVehicle
  L2_2 = L0_2
  L1_2 = L1_2(L2_2)
  L1_2 = 1 == L1_2
  L2_2 = nil
  if L1_2 then
    L3_2 = GetVehicleType
    L4_2 = GetVehiclePedIsIn
    L5_2 = L0_2
    L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2 = L4_2(L5_2)
    L3_2 = L3_2(L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2)
    if "bike" ~= L3_2 then
      L3_2 = GetVehiclePedIsIn
      L4_2 = L0_2
      L3_2 = L3_2(L4_2)
      L2_2 = L3_2
    else
      L1_2 = false
      L2_2 = L0_2
    end
  else
    L2_2 = L0_2
  end
  L3_2 = PauseMenu
  L3_2 = L3_2.LastRecordedCamState
  if not L3_2 then
    L3_2 = PauseMenu
    L4_2 = GetFollowPedCamViewMode
    L4_2 = L4_2()
    L3_2.LastRecordedCamState = L4_2
    L3_2 = PauseMenu
    L3_2 = L3_2.LastRecordedCamState
    if 4 == L3_2 then
      L3_2 = SetFollowPedCamViewMode
      L4_2 = 1
      L3_2(L4_2)
    end
  end
  if L1_2 then
    L3_2 = CameraAngles
    L3_2 = L3_2.Vehicle
    L3_2 = L3_2.pause_menu
    L3_2 = L3_2.cam
    if L3_2 then
      goto lbl_58
    end
  end
  L3_2 = CameraAngles
  L3_2 = L3_2.Player
  L3_2 = L3_2.pause_menu
  L3_2 = L3_2.cam
  ::lbl_58::
  if L1_2 then
    L4_2 = CameraAngles
    L4_2 = L4_2.Vehicle
    L4_2 = L4_2.pause_menu
    L4_2 = L4_2.focus
    if L4_2 then
      goto lbl_70
    end
  end
  L4_2 = CameraAngles
  L4_2 = L4_2.Player
  L4_2 = L4_2.pause_menu
  L4_2 = L4_2.focus
  ::lbl_70::
  L5_2 = GetEntityCoords
  L6_2 = L2_2
  L5_2 = L5_2(L6_2)
  L6_2 = GetEntityHeading
  L7_2 = L2_2
  L6_2 = L6_2(L7_2)
  L7_2 = _ENV
  L8_2 = "GetOffsetFromCoordAndHeadingInWorldCoords"
  L7_2 = L7_2[L8_2]
  L8_2 = L5_2.x
  L9_2 = L5_2.y
  L10_2 = L5_2.z
  L11_2 = L6_2
  L12_2 = L4_2.x
  L13_2 = L4_2.y
  L14_2 = L4_2.z
  L7_2 = L7_2(L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2)
  L8_2 = _ENV
  L9_2 = "GetOffsetFromCoordAndHeadingInWorldCoords"
  L8_2 = L8_2[L9_2]
  L9_2 = L5_2.x
  L10_2 = L5_2.y
  L11_2 = L5_2.z
  L12_2 = L6_2
  L13_2 = L3_2.x
  L14_2 = L3_2.y
  L15_2 = L3_2.z
  L8_2 = L8_2(L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2)
  L9_2 = Cameras
  L9_2 = L9_2.GetEulerRotationsFromCoords
  L10_2 = L7_2
  L11_2 = L8_2
  L9_2 = L9_2(L10_2, L11_2)
  if L1_2 then
    L10_2 = CameraAngles
    L10_2 = L10_2.Vehicle
    L10_2 = L10_2.pause_menu
    L10_2 = L10_2.fov
    if L10_2 then
      goto lbl_115
    end
  end
  L10_2 = CameraAngles
  L10_2 = L10_2.Player
  L10_2 = L10_2.pause_menu
  L10_2 = L10_2.fov
  ::lbl_115::
  L11_2 = PauseMenu
  L12_2 = CreateCamWithParams
  L13_2 = "DEFAULT_SCRIPTED_CAMERA"
  L14_2 = L8_2
  L15_2 = L9_2
  L16_2 = L10_2
  L17_2 = true
  L18_2 = 2
  L12_2 = L12_2(L13_2, L14_2, L15_2, L16_2, L17_2, L18_2)
  L11_2.Cam = L12_2
  L11_2 = RenderScriptCams
  L12_2 = true
  L13_2 = true
  L11_2(L12_2, L13_2)
  L11_2 = SetCamActive
  L12_2 = PauseMenu
  L12_2 = L12_2.Cam
  L13_2 = true
  L11_2(L12_2, L13_2)
  L11_2 = SetCamUseShallowDofMode
  L12_2 = PauseMenu
  L12_2 = L12_2.Cam
  L13_2 = true
  L11_2(L12_2, L13_2)
  L11_2 = SetCamNearDof
  L12_2 = PauseMenu
  L12_2 = L12_2.Cam
  L13_2 = 0.0
  L11_2(L12_2, L13_2)
  L11_2 = SetCamFarDof
  L12_2 = PauseMenu
  L12_2 = L12_2.Cam
  L13_2 = 12.3
  L11_2(L12_2, L13_2)
  L11_2 = SetCamDofStrength
  L12_2 = PauseMenu
  L12_2 = L12_2.Cam
  L13_2 = 20.8
  L11_2(L12_2, L13_2)
  while true do
    L11_2 = DoesCamExist
    L12_2 = PauseMenu
    L12_2 = L12_2.Cam
    L11_2 = L11_2(L12_2)
    if L11_2 then
      break
    end
    L11_2 = Wait
    L12_2 = 0
    L11_2(L12_2)
  end
  L11_2 = Citizen
  L11_2 = L11_2.CreateThread
  function L12_2()
    local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3
    L0_3 = StartAudioScene
    L1_3 = "DEATH_SCENE"
    L0_3(L1_3)
    while true do
      L0_3 = PauseMenu
      L0_3 = L0_3.Cam
      if false == L0_3 then
        break
      end
      L0_3 = Wait
      L1_3 = 0
      L0_3(L1_3)
      L0_3 = GetEntityCoords
      L1_3 = L2_2
      L0_3 = L0_3(L1_3)
      L5_2 = L0_3
      L0_3 = GetEntityHeading
      L1_3 = L2_2
      L0_3 = L0_3(L1_3)
      L6_2 = L0_3
      L0_3 = _ENV
      L1_3 = "GetOffsetFromCoordAndHeadingInWorldCoords"
      L0_3 = L0_3[L1_3]
      L1_3 = L5_2.x
      L2_3 = L5_2.y
      L3_3 = L5_2.z
      L4_3 = L6_2
      L5_3 = L4_2.x
      L6_3 = L4_2.y
      L7_3 = L4_2.z
      L0_3 = L0_3(L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3)
      L7_2 = L0_3
      L0_3 = _ENV
      L1_3 = "GetOffsetFromCoordAndHeadingInWorldCoords"
      L0_3 = L0_3[L1_3]
      L1_3 = L5_2.x
      L2_3 = L5_2.y
      L3_3 = L5_2.z
      L4_3 = L6_2
      L5_3 = L3_2.x
      L6_3 = L3_2.y
      L7_3 = L3_2.z
      L0_3 = L0_3(L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3)
      L8_2 = L0_3
      L0_3 = Cameras
      L0_3 = L0_3.GetEulerRotationsFromCoords
      L1_3 = L7_2
      L2_3 = L8_2
      L0_3 = L0_3(L1_3, L2_3)
      L9_2 = L0_3
      L0_3 = SetCamCoord
      L1_3 = PauseMenu
      L1_3 = L1_3.Cam
      L2_3 = L8_2
      L0_3(L1_3, L2_3)
      L0_3 = SetCamRot
      L1_3 = PauseMenu
      L1_3 = L1_3.Cam
      L2_3 = L9_2
      L3_3 = 2
      L0_3(L1_3, L2_3, L3_3)
      L0_3 = SetUseHiDof
      L0_3()
    end
    L0_3 = StopAudioScene
    L1_3 = "DEATH_SCENE"
    L0_3(L1_3)
  end
  L11_2(L12_2)
end
L0_1.CreateCamInstance = L1_1
L0_1 = PauseMenu
function L1_1(A0_2)
  local L1_2, L2_2, L3_2
  L1_2 = PauseMenu
  L1_2 = L1_2.Cam
  if not L1_2 then
    return
  end
  L1_2 = DestroyCam
  L2_2 = PauseMenu
  L2_2 = L2_2.Cam
  L1_2(L2_2)
  L1_2 = RenderScriptCams
  L2_2 = false
  L3_2 = false
  L1_2(L2_2, L3_2)
  L1_2 = PauseMenu
  L1_2.Cam = false
  L1_2 = SetFollowPedCamViewMode
  L2_2 = PauseMenu
  L2_2 = L2_2.LastRecordedCamState
  L1_2(L2_2)
  L1_2 = PauseMenu
  L1_2.LastRecordedCamState = false
end
L0_1.DestroyCam = L1_1
L0_1 = RegisterNUICallback
L1_1 = "pausemenu.handleCamera"
function L2_1(A0_2)
  local L1_2, L2_2, L3_2
  L1_2 = A0_2.state
  L2_2 = PauseMenu
  L2_2.IsActive = L1_2
  if L1_2 then
    L2_2 = PauseMenu
    L2_2 = L2_2.CreateCamInstance
    L2_2()
  else
    L2_2 = PauseMenu
    L2_2 = L2_2.DestroyCam
    L3_2 = A0_2.force
    L2_2(L3_2)
  end
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNUICallback
L1_1 = "pauseMenu.left"
function L2_1()
  local L0_2, L1_2, L2_2
  L0_2 = SetNuiFocus
  L1_2 = false
  L2_2 = false
  L0_2(L1_2, L2_2)
  L0_2 = Config
  L0_2 = L0_2.PersistentMinimap
  if L0_2 then
    L0_2 = Citizen
    L0_2 = L0_2.CreateThread
    function L1_2()
      local L0_3, L1_3
      L0_3 = Wait
      L1_3 = 100
      L0_3(L1_3)
      L0_3 = NUI
      L0_3 = L0_3.IsInterfaceDisabled
      if not L0_3 then
        L0_3 = DisplayRadar
        L1_3 = true
        L0_3(L1_3)
      end
    end
    L0_2(L1_2)
  end
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNUICallback
L1_1 = "pausemenu.disconnect"
function L2_1()
  local L0_2, L1_2
  L0_2 = debugPrint
  L1_2 = "Disconnecting [/]"
  L0_2(L1_2)
  L0_2 = TriggerServerEvent
  L1_2 = "ZSX_UIV2:Quit"
  L0_2(L1_2)
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNUICallback
L1_1 = "pausemenu.handleNav"
function L2_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2
  L1_2 = A0_2.path
  L2_2 = PauseMenu
  L2_2 = L2_2.SomePartIsStillOpening
  if L2_2 then
    return
  end
  L2_2 = PauseMenu
  L2_2 = L2_2.Disable
  L2_2()
  L2_2 = L1_2.type
  if "game" == L2_2 then
    L2_2 = L1_2.value
    if "map" == L2_2 then
      L2_2 = Citizen
      L2_2 = L2_2.CreateThread
      function L3_2()
        local L0_3, L1_3, L2_3, L3_3
        L0_3 = PauseMenu
        L0_3.SomePartIsStillOpening = true
        L0_3 = NUI
        L0_3 = L0_3.SetUIVisible
        L1_3 = false
        L0_3(L1_3)
        L0_3 = ActivateFrontendMenu
        L1_3 = GetHashKey
        L2_3 = "FE_MENU_VERSION_MP_PAUSE"
        L1_3 = L1_3(L2_3)
        L2_3 = 0
        L3_3 = -1
        L0_3(L1_3, L2_3, L3_3)
        L0_3 = IsPauseMenuActive
        L0_3 = L0_3()
        if L0_3 then
          L0_3 = IsPauseMenuRestarting
          L0_3 = L0_3()
          if not L0_3 then
            goto lbl_34
          end
        end
        while true do
          L0_3 = IsPauseMenuActive
          L0_3 = L0_3()
          if L0_3 then
            L0_3 = IsPauseMenuRestarting
            L0_3 = L0_3()
            if not L0_3 then
              break
            end
          end
          L0_3 = Wait
          L1_3 = 0
          L0_3(L1_3)
        end
        ::lbl_34::
        L0_3 = GameMenu
        L0_3 = L0_3.CreateCameraAngle
        L1_3 = "map"
        L0_3(L1_3)
        L0_3 = Citizen
        L0_3 = L0_3.CreateThread
        function L1_3()
          local L0_4, L1_4
          L0_4 = Wait
          L1_4 = 50
          L0_4(L1_4)
          L0_4 = PauseMenuceptionGoDeeper
          L1_4 = 0
          L0_4(L1_4)
          L0_4 = PauseMenuceptionTheKick
          L0_4()
        end
        L0_3(L1_3)
        L0_3 = DisplayRadar
        L1_3 = false
        L2_3 = true
        L0_3(L1_3, L2_3)
        L0_3 = StartAudioScene
        L1_3 = "DEATH_SCENE"
        L0_3(L1_3)
        while true do
          L0_3 = Citizen
          L0_3 = L0_3.Wait
          L1_3 = 0
          L0_3(L1_3)
          L0_3 = IsControlJustPressed
          L1_3 = 0
          L2_3 = 200
          L0_3 = L0_3(L1_3, L2_3)
          if not L0_3 then
            L0_3 = IsControlJustPressed
            L1_3 = 0
            L2_3 = 177
            L0_3 = L0_3(L1_3, L2_3)
            if not L0_3 then
              L0_3 = IsControlJustPressed
              L1_3 = 0
              L2_3 = 202
              L0_3 = L0_3(L1_3, L2_3)
              if not L0_3 then
                goto lbl_75
              end
            end
          end
          L0_3 = SetFrontendActive
          L1_3 = 0
          L0_3(L1_3)
          do break end
          ::lbl_75::
        end
        L0_3 = PauseMenu
        L0_3.SomePartIsStillOpening = false
        L0_3 = StopAudioScene
        L1_3 = "DEATH_SCENE"
        L0_3(L1_3)
        L0_3 = NUI
        L0_3 = L0_3.SetUIVisible
        L1_3 = true
        L0_3(L1_3)
        L0_3 = GameMenu
        L0_3 = L0_3.DestroyCamera
        L0_3()
        L0_3 = PauseMenu
        L0_3 = L0_3.Init
        L0_3()
      end
      L2_2(L3_2)
    else
      L2_2 = L1_2.value
      if "settings" == L2_2 then
        L2_2 = Citizen
        L2_2 = L2_2.CreateThread
        function L3_2()
          local L0_3, L1_3, L2_3, L3_3
          L0_3 = PauseMenu
          L0_3.SomePartIsStillOpening = true
          L0_3 = NUI
          L0_3 = L0_3.SetUIVisible
          L1_3 = false
          L0_3(L1_3)
          L0_3 = ActivateFrontendMenu
          L1_3 = GetHashKey
          L2_3 = "FE_MENU_VERSION_LANDING_MENU"
          L1_3 = L1_3(L2_3)
          L2_3 = 0
          L3_3 = -1
          L0_3(L1_3, L2_3, L3_3)
          L0_3 = Wait
          L1_3 = 100
          L0_3(L1_3)
          L0_3 = GameMenu
          L0_3 = L0_3.CreateCameraAngle
          L1_3 = "settings"
          L0_3(L1_3)
          L0_3 = DisplayRadar
          L1_3 = false
          L2_3 = true
          L0_3(L1_3, L2_3)
          L0_3 = StartAudioScene
          L1_3 = "DEATH_SCENE"
          L0_3(L1_3)
          L0_3 = LocalPlayer
          L0_3 = L0_3.state
          L1_3 = L0_3
          L0_3 = L0_3.set
          L2_3 = "UI_InSettings"
          L3_3 = true
          L0_3(L1_3, L2_3, L3_3)
          while true do
            L0_3 = GetCurrentFrontendMenuVersion
            L0_3 = L0_3()
            L1_3 = GetHashKey
            L2_3 = "FE_MENU_VERSION_LANDING_MENU"
            L1_3 = L1_3(L2_3)
            if L0_3 ~= L1_3 then
              break
            end
            L0_3 = Citizen
            L0_3 = L0_3.Wait
            L1_3 = 0
            L0_3(L1_3)
          end
          L0_3 = PauseMenu
          L0_3.SomePartIsStillOpening = false
          L0_3 = LocalPlayer
          L0_3 = L0_3.state
          L1_3 = L0_3
          L0_3 = L0_3.set
          L2_3 = "UI_InSettings"
          L3_3 = false
          L0_3(L1_3, L2_3, L3_3)
          L0_3 = StopAudioScene
          L1_3 = "DEATH_SCENE"
          L0_3(L1_3)
          L0_3 = NUI
          L0_3 = L0_3.SetUIVisible
          L1_3 = true
          L0_3(L1_3)
          L0_3 = GameMenu
          L0_3 = L0_3.DestroyCamera
          L0_3()
          L0_3 = PauseMenu
          L0_3 = L0_3.Init
          L0_3()
        end
        L2_2(L3_2)
      end
    end
  else
    L2_2 = L1_2.type
    if "custom_payload" == L2_2 then
      L2_2 = L1_2.export
      if L2_2 then
        L2_2 = exports
        L3_2 = L1_2.export
        L3_2 = L3_2.resource
        L2_2 = L2_2[L3_2]
        L3_2 = L1_2.export
        L3_2 = L3_2.exportFunction
        L2_2 = L2_2[L3_2]
        L3_2 = L1_2.params
        if L3_2 then
          L3_2 = table
          L3_2 = L3_2.unpack
          L4_2 = L1_2.params
          L3_2 = L3_2(L4_2)
          if L3_2 then
            goto lbl_52
          end
        end
        L3_2 = ""
        ::lbl_52::
        L2_2(L3_2)
      else
        L2_2 = L1_2.event
        if L2_2 then
          L2_2 = L1_2.event
          L2_2 = L2_2.type
          if "client" == L2_2 then
            L2_2 = TriggerEvent
            L3_2 = L1_2.event
            L3_2 = L3_2.name
            L4_2 = L1_2.params
            if L4_2 then
              L4_2 = table
              L4_2 = L4_2.unpack
              L5_2 = L1_2.params
              L4_2 = L4_2(L5_2)
              if L4_2 then
                goto lbl_74
              end
            end
            L4_2 = ""
            ::lbl_74::
            L2_2(L3_2, L4_2)
          else
            L2_2 = L1_2.event
            L2_2 = L2_2.type
            if "server" == L2_2 then
              L2_2 = TriggerServerEvent
              L3_2 = L1_2.event
              L3_2 = L3_2.name
              L4_2 = L1_2.params
              if L4_2 then
                L4_2 = table
                L4_2 = L4_2.unpack
                L5_2 = L1_2.params
                L4_2 = L4_2(L5_2)
                if L4_2 then
                  goto lbl_93
                end
              end
              L4_2 = ""
              ::lbl_93::
              L2_2(L3_2, L4_2)
            end
          end
        end
      end
    end
  end
end
L0_1(L1_1, L2_1)
L0_1 = RegisterCommand
L1_1 = "pause_menu"
function L2_1()
  local L0_2, L1_2
  L0_2 = Storage
  L0_2 = L0_2.CurrentScreen
  if "cinematic_mode" == L0_2 then
    return
  end
  L0_2 = Workers
  L0_2 = L0_2.PauseMenu
  L0_2 = L0_2.PreventOpen
  L0_2 = L0_2()
  if L0_2 then
    L0_2 = debugPrint
    L1_2 = "[^1PREVENT^7] Can not open up pause menu. Something else is open!"
    return L0_2(L1_2)
  end
  L0_2 = PauseMenu
  L0_2 = L0_2.Init
  L0_2()
end
L0_1(L1_1, L2_1)
L0_1 = RegisterKeyMapping
L1_1 = "pause_menu"
L2_1 = "Opens Pause Menu"
L3_1 = "KEYBOARD"
L4_1 = "ESCAPE"
L0_1(L1_1, L2_1, L3_1, L4_1)
L0_1 = Config
L0_1 = L0_1.UI
L0_1 = L0_1.UsePauseMenu
if L0_1 then
  L0_1 = Citizen
  L0_1 = L0_1.CreateThread
  function L1_1()
    local L0_2, L1_2, L2_2
    L0_2 = Config
    L0_2 = L0_2.DisablePauseMenuInterval
    if not L0_2 then
      L0_2 = 5
    end
    while true do
      L1_2 = SetPauseMenuActive
      L2_2 = false
      L1_2(L2_2)
      L1_2 = Citizen
      L1_2 = L1_2.Wait
      L2_2 = L0_2
      L1_2(L2_2)
    end
  end
  L0_1(L1_1)
else
  L0_1 = Citizen
  L0_1 = L0_1.CreateThread
  function L1_1()
    local L0_2, L1_2, L2_2, L3_2
    L0_2 = false
    while true do
      L1_2 = IsPauseMenuActive
      L1_2 = L1_2()
      if L1_2 ~= L0_2 then
        L2_2 = NUI
        L2_2 = L2_2.SetRoutePath
        if L1_2 then
          L3_2 = "/blank"
          if L3_2 then
            goto lbl_14
          end
        end
        L3_2 = "/"
        ::lbl_14::
        L2_2(L3_2)
        L0_2 = L1_2
      end
      L2_2 = Wait
      L3_2 = 1000
      L2_2(L3_2)
    end
  end
  L0_1(L1_1)
end
L0_1 = Config
L0_1 = L0_1.UI
L0_1 = L0_1.UseListenerForMumble
if L0_1 then
  L0_1 = Config
  L0_1 = L0_1.Voice
  L0_1 = L0_1.DoesSaltyChatExists
  if not L0_1 then
    L0_1 = Config
    L0_1 = L0_1.UI
    L0_1 = L0_1.DisableVoiceIndicator
    if not L0_1 then
      L0_1 = Citizen
      L0_1 = L0_1.CreateThread
      function L1_1()
        local L0_2, L1_2, L2_2, L3_2
        while true do
          L0_2 = MumbleIsPlayerTalking
          L1_2 = Threads
          L1_2 = L1_2.Players
          L1_2 = L1_2.Data
          L1_2 = L1_2.player
          L0_2 = L0_2(L1_2)
          L0_2 = 1 == L0_2
          L1_2 = playerTalkingLastState
          if L1_2 ~= L0_2 then
            L1_2 = Config
            L1_2 = L1_2.UI
            L1_2 = L1_2.Use3DVoiceIndicator
            if not L1_2 then
              if L0_2 then
                L1_2 = TopContent
                L1_2 = L1_2.SetScreen
                L2_2 = "voice"
                L1_2(L2_2)
              end
              L1_2 = TopContent
              L1_2 = L1_2.Init
              L2_2 = L0_2
              L1_2(L2_2)
            else
              L1_2 = NUI
              L1_2 = L1_2.SendMessage
              L2_2 = "SET_VOICE_INDICATOR_PLAYER_TALKING"
              L3_2 = {}
              L3_2.state = L0_2
              L1_2(L2_2, L3_2)
            end
            playerTalkingLastState = L0_2
          end
          L1_2 = Wait
          L2_2 = 300
          L1_2(L2_2)
        end
      end
      L0_1(L1_1)
    end
  end
end
