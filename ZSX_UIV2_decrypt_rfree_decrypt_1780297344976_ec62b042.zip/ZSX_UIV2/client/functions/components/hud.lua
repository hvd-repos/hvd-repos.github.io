local L0_1, L1_1, L2_1
L0_1 = {}
Hud = L0_1
L0_1 = Hud
function L1_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2
  L2_2 = NUI
  L2_2 = L2_2.SendMessage
  L3_2 = "UPDATE_HUD_VALUE"
  L4_2 = {}
  L4_2.key = A0_2
  L4_2.value = A1_2
  L2_2(L3_2, L4_2)
end
L0_1.UpdateKeyValue = L1_1
L0_1 = {}
Status = L0_1
L0_1 = Status
L1_1 = {}
L0_1.Memory = L1_1
L0_1 = Status
function L1_1(A0_2, A1_2, A2_2, A3_2)
  local L4_2, L5_2, L6_2, L7_2, L8_2
  L4_2 = NUI
  L4_2 = L4_2.Loaded
  if L4_2 then
    L4_2 = Storage
    L4_2 = L4_2.HasBeenSent
    if L4_2 then
      goto lbl_21
    end
  end
  while true do
    L4_2 = NUI
    L4_2 = L4_2.Loaded
    if L4_2 then
      L4_2 = Storage
      L4_2 = L4_2.HasBeenSent
      if L4_2 then
        break
      end
    end
    L4_2 = Wait
    L5_2 = 1000
    L4_2(L5_2)
  end
  ::lbl_21::
  L4_2 = Config
  L4_2 = L4_2.Hud
  L4_2 = L4_2.Status
  L4_2 = L4_2[A0_2]
  if L4_2 then
    L4_2 = debugPrint
    L5_2 = string
    L5_2 = L5_2.format
    L6_2 = "[^2STATUS^7] [^1REGISTER^7] There is already status registered with name [^2%s^7]"
    L7_2 = A0_2
    L5_2, L6_2, L7_2, L8_2 = L5_2(L6_2, L7_2)
    return L4_2(L5_2, L6_2, L7_2, L8_2)
  end
  L4_2 = Status
  L4_2 = L4_2.Memory
  L4_2 = L4_2[A0_2]
  if L4_2 then
    L4_2 = debugPrint
    L5_2 = string
    L5_2 = L5_2.format
    L6_2 = "[^2STATUS^7] [^1REGISTER^7] There is already pending status to be registered with name [^2%s^7]"
    L7_2 = A0_2
    L5_2, L6_2, L7_2, L8_2 = L5_2(L6_2, L7_2)
    return L4_2(L5_2, L6_2, L7_2, L8_2)
  end
  if not A3_2 then
    L4_2 = debugPrint
    L5_2 = string
    L5_2 = L5_2.format
    L6_2 = "[^2STATUS^7] [^1REGISTER^7] Param ^1getFunction^7 is not defined for status with name [^2%s^7]"
    L7_2 = A0_2
    L5_2, L6_2, L7_2, L8_2 = L5_2(L6_2, L7_2)
    return L4_2(L5_2, L6_2, L7_2, L8_2)
  end
  L4_2 = type
  L5_2 = A3_2
  L4_2 = L4_2(L5_2)
  if "function" ~= L4_2 then
    L4_2 = debugPrint
    L5_2 = string
    L5_2 = L5_2.format
    L6_2 = "[^2STATUS^7] [^1REGISTER^7] Param ^1getFunction^7 is not a function for status with name [^2%s^7]"
    L7_2 = A0_2
    L5_2, L6_2, L7_2, L8_2 = L5_2(L6_2, L7_2)
    return L4_2(L5_2, L6_2, L7_2, L8_2)
  end
  L4_2 = A3_2
  L4_2 = L4_2()
  if nil == L4_2 then
    L4_2 = debugPrint
    L5_2 = string
    L5_2 = L5_2.format
    L6_2 = "[^2STATUS^7] [^1REGISTER^7] Param ^1getFunction^7 does not return anything for status with name [^2%s^7]"
    L7_2 = A0_2
    L5_2, L6_2, L7_2, L8_2 = L5_2(L6_2, L7_2)
    return L4_2(L5_2, L6_2, L7_2, L8_2)
  end
  L4_2 = type
  L5_2 = A3_2
  L5_2, L6_2, L7_2, L8_2 = L5_2()
  L4_2 = L4_2(L5_2, L6_2, L7_2, L8_2)
  if "number" ~= L4_2 then
    L4_2 = debugPrint
    L5_2 = string
    L5_2 = L5_2.format
    L6_2 = "[^2STATUS^7] [^1REGISTER^7] Param ^1getFunction^7 does not return a number for status with name [^2%s^7]"
    L7_2 = A0_2
    L5_2, L6_2, L7_2, L8_2 = L5_2(L6_2, L7_2)
    return L4_2(L5_2, L6_2, L7_2, L8_2)
  end
  L4_2 = Status
  L4_2 = L4_2.Memory
  L5_2 = {}
  L5_2.name = A0_2
  L5_2.icon = A1_2
  L6_2 = A2_2 or L6_2
  if not A2_2 then
    L6_2 = 0
  end
  L5_2.value = L6_2
  L5_2.isVisible = true
  L5_2.get = A3_2
  L4_2[A0_2] = L5_2
  L4_2 = NUI
  L4_2 = L4_2.SendMessage
  L5_2 = "HANDLE_REGISTER_STATUS_HUD"
  L6_2 = {}
  L6_2.register = true
  L6_2.statusName = A0_2
  L7_2 = {}
  L7_2.name = A0_2
  L7_2.icon = A1_2
  L8_2 = A2_2 or L8_2
  if not A2_2 then
    L8_2 = 0
  end
  L7_2.value = L8_2
  L7_2.isVisible = true
  L6_2.statusData = L7_2
  L6_2.statusVisible = true
  L4_2(L5_2, L6_2)
end
L0_1.RegisterStatus = L1_1
L0_1 = Status
function L1_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2
  L1_2 = NUI
  L1_2 = L1_2.Loaded
  if L1_2 then
    L1_2 = Storage
    L1_2 = L1_2.HasBeenSent
    if L1_2 then
      goto lbl_21
    end
  end
  while true do
    L1_2 = NUI
    L1_2 = L1_2.Loaded
    if L1_2 then
      L1_2 = Storage
      L1_2 = L1_2.HasBeenSent
      if L1_2 then
        break
      end
    end
    L1_2 = Wait
    L2_2 = 1000
    L1_2(L2_2)
  end
  ::lbl_21::
  L1_2 = Config
  L1_2 = L1_2.Hud
  L1_2 = L1_2.Status
  L1_2 = L1_2[A0_2]
  if not L1_2 then
    L1_2 = debugPrint
    L2_2 = string
    L2_2 = L2_2.format
    L3_2 = "[^2STATUS^7] [^1UNREGISTER^7] Could not find any status with name [^2%s^7]"
    L4_2 = A0_2
    L2_2, L3_2, L4_2 = L2_2(L3_2, L4_2)
    return L1_2(L2_2, L3_2, L4_2)
  end
  L1_2 = NUI
  L1_2 = L1_2.SendMessage
  L2_2 = "HANDLE_REGISTER_STATUS_HUD"
  L3_2 = {}
  L3_2.register = false
  L3_2.statusName = A0_2
  L4_2 = {}
  L3_2.statusData = L4_2
  L1_2(L2_2, L3_2)
end
L0_1.UnregisterStatus = L1_1
L0_1 = RegisterNUICallback
L1_1 = "status.onRegister"
function L2_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2
  L1_2 = Config
  L1_2 = L1_2.Hud
  L1_2 = L1_2.Status
  L2_2 = A0_2.statusName
  L3_2 = Status
  L3_2 = L3_2.Memory
  L4_2 = A0_2.statusName
  L3_2 = L3_2[L4_2]
  L1_2[L2_2] = L3_2
  L1_2 = debugPrint
  L2_2 = string
  L2_2 = L2_2.format
  L3_2 = "[^2STATUS^7] [^2REGISTER^7] Registered status with name [^2%s^7]"
  L4_2 = A0_2.statusName
  L2_2, L3_2, L4_2 = L2_2(L3_2, L4_2)
  L1_2(L2_2, L3_2, L4_2)
  L1_2 = Status
  L1_2 = L1_2.Memory
  L2_2 = A0_2.statusName
  L1_2[L2_2] = nil
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNUICallback
L1_1 = "status.onUnregister"
function L2_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2
  L1_2 = Config
  L1_2 = L1_2.Hud
  L1_2 = L1_2.Status
  L2_2 = A0_2.statusName
  L1_2[L2_2] = nil
  L1_2 = debugPrint
  L2_2 = string
  L2_2 = L2_2.format
  L3_2 = "[^2STATUS^7] [^2UNREGISTER^7] Unregistered status with name [^2%s^7]"
  L4_2 = A0_2.statusName
  L2_2, L3_2, L4_2 = L2_2(L3_2, L4_2)
  L1_2(L2_2, L3_2, L4_2)
end
L0_1(L1_1, L2_1)
