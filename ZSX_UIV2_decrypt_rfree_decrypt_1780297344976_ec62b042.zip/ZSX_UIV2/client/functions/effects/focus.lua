local L0_1, L1_1
L0_1 = Effects
L1_1 = {}
L0_1.Focus = L1_1
L0_1 = Effects
L0_1 = L0_1.Focus
L0_1.InitialFov = 0
L0_1 = Effects
L0_1 = L0_1.Focus
function L1_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2
  L1_2 = GetRenderingCam
  L1_2 = L1_2()
  if A0_2 then
    L2_2 = Effects
    L2_2 = L2_2.Focus
    L3_2 = GetCamFov
    L4_2 = L1_2
    L3_2 = L3_2(L4_2)
    L2_2.InitialFov = L3_2
    L2_2 = SetCamFov
    L3_2 = L1_2
    L4_2 = 120.0
    L2_2(L3_2, L4_2)
  else
    L2_2 = SetCamFov
    L3_2 = L1_2
    L4_2 = Effects
    L4_2 = L4_2.Focus
    L4_2 = L4_2.InitialFov
    L2_2(L3_2, L4_2)
  end
end
L0_1.Init = L1_1
