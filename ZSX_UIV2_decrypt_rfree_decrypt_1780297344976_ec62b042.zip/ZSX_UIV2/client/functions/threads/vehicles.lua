local L0_1, L1_1, L2_1, L3_1
L0_1 = Threads
L1_1 = {}
L0_1.Vehicles = L1_1
L0_1 = Threads
L0_1 = L0_1.Vehicles
L0_1.Use = false
L0_1 = Threads
L0_1 = L0_1.Vehicles
L0_1.StreetLabelUse = false
L0_1 = Threads
L0_1 = L0_1.Vehicles
L1_1 = {}
L0_1.BlacklistedHashModels = L1_1
L0_1 = Threads
L0_1 = L0_1.Vehicles
L1_1 = {}
L1_1.vehicle = 0
L1_1.rpm = 0
L1_1.speed = 0
L1_1.gear = 0
L1_1.fuel = 0
L1_1.acceleration = 0
L0_1.Data = L1_1
L0_1 = Threads
L0_1 = L0_1.Vehicles
L0_1.IsRadarVisible = false
L0_1 = Threads
L0_1 = L0_1.Vehicles
L1_1 = Config
L1_1 = L1_1.UI
L1_1 = L1_1.Preset
L1_1 = L1_1.carhud
L1_1 = L1_1.refreshInterval
L0_1.RefreshInterval = L1_1
L0_1 = Threads
L0_1 = L0_1.Vehicles
L1_1 = {}
L0_1.DirectionList = L1_1
L0_1 = Citizen
L0_1 = L0_1.CreateThread
function L1_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2
  L0_2 = 0
  L1_2 = 360
  L2_2 = 1
  for L3_2 = L0_2, L1_2, L2_2 do
    L4_2 = Threads
    L4_2 = L4_2.Vehicles
    L4_2 = L4_2.DirectionList
    if L3_2 >= 0 and L3_2 < 45 then
      L5_2 = "N"
      if L5_2 then
        goto lbl_76
      end
    end
    if L3_2 >= 45 and L3_2 < 90 then
      L5_2 = "NW"
      if L5_2 then
        goto lbl_76
      end
    end
    if L3_2 >= 90 then
      L5_2 = 135
      if L3_2 < L5_2 then
        L5_2 = "W"
        if L5_2 then
          goto lbl_76
        end
      end
    end
    L5_2 = 135
    if L3_2 >= L5_2 then
      L5_2 = 180
      if L3_2 < L5_2 then
        L5_2 = "SW"
        if L5_2 then
          goto lbl_76
        end
      end
    end
    L5_2 = 180
    if L3_2 >= L5_2 then
      L5_2 = 225
      if L3_2 < L5_2 then
        L5_2 = "S"
        if L5_2 then
          goto lbl_76
        end
      end
    end
    L5_2 = 225
    if L3_2 >= L5_2 then
      L5_2 = 270
      if L3_2 < L5_2 then
        L5_2 = "SE"
        if L5_2 then
          goto lbl_76
        end
      end
    end
    L5_2 = 270
    if L3_2 >= L5_2 then
      L5_2 = 315
      if L3_2 < L5_2 then
        L5_2 = "E"
        if L5_2 then
          goto lbl_76
        end
      end
    end
    L5_2 = 315
    L5_2 = 360
    L5_2 = L3_2 >= L5_2 and L5_2
    ::lbl_76::
    L4_2[L3_2] = L5_2
  end
  L0_2 = pairs
  L1_2 = Config
  L1_2 = L1_2.BlacklistedVehicles
  L0_2, L1_2, L2_2, L3_2 = L0_2(L1_2)
  for L4_2, L5_2 in L0_2, L1_2, L2_2, L3_2 do
    L6_2 = Threads
    L6_2 = L6_2.Vehicles
    L6_2 = L6_2.BlacklistedHashModels
    L7_2 = tostring
    L8_2 = GetHashKey
    L9_2 = L4_2
    L8_2, L9_2 = L8_2(L9_2)
    L7_2 = L7_2(L8_2, L9_2)
    L6_2[L7_2] = true
  end
end
L0_1(L1_1)
L0_1 = Threads
L0_1 = L0_1.Vehicles
function L1_1()
  local L0_2, L1_2
  L0_2 = Threads
  L0_2 = L0_2.Vehicles
  L0_2.Use = true
  L0_2 = Threads
  L0_2 = L0_2.Vehicles
  L0_2.IdleTime = 1000
  L0_2 = Config
  L0_2 = L0_2.UseOxLibCache
  if L0_2 then
    L0_2 = debugPrint
    L1_2 = "[^6THREADS^7] [^2CARHUD^7] Using ox lib cache [/]"
    L0_2(L1_2)
  end
  L0_2 = Citizen
  L0_2 = L0_2.CreateThread
  function L1_2()
    local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3, L16_3, L17_3, L18_3
    L0_3 = Threads
    L0_3 = L0_3.Vehicles
    L0_3 = L0_3.IdleTime
    L1_3 = L0_3
    L2_3 = Config
    L2_3 = L2_3.Metrics
    if "kmh" == L2_3 then
      L2_3 = 3.6
      if L2_3 then
        goto lbl_13
      end
    end
    L2_3 = 2.236936
    ::lbl_13::
    L3_3 = debugPrint
    L4_3 = "[^6THREADS^7] CARHUD interval set to ^2"
    L5_3 = math
    L5_3 = L5_3.floor
    L6_3 = Threads
    L6_3 = L6_3.Vehicles
    L6_3 = L6_3.RefreshInterval
    L6_3 = L6_3.current
    L5_3 = L5_3(L6_3)
    L6_3 = "ms^7"
    L4_3 = L4_3 .. L5_3 .. L6_3
    L3_3(L4_3)
    while true do
      L3_3 = Threads
      L3_3 = L3_3.Vehicles
      L3_3 = L3_3.Use
      if not L3_3 then
        break
      end
      L3_3 = false
      L4_3 = nil
      L5_3 = Config
      L5_3 = L5_3.UseOxLibCache
      if L5_3 then
        L5_3 = cache
        L4_3 = L5_3 or L4_3
        if L5_3 then
          L5_3 = cache
          L4_3 = L5_3.vehicle
        end
      else
        L5_3 = IsPedInAnyVehicle
        L6_3 = Threads
        L6_3 = L6_3.Players
        L6_3 = L6_3.Data
        L6_3 = L6_3.ped
        L5_3 = L5_3(L6_3)
        L4_3 = 1 == L5_3
      end
      if L4_3 then
        L5_3 = Threads
        L5_3 = L5_3.Vehicles
        L5_3 = L5_3.Data
        L5_3 = L5_3.doesExist
        if not L5_3 then
          L5_3 = Threads
          L5_3 = L5_3.Vehicles
          L5_3 = L5_3.Data
          if L4_3 then
            L6_3 = DoesEntityExist
            L7_3 = Threads
            L7_3 = L7_3.Vehicles
            L7_3 = L7_3.Data
            L7_3 = L7_3.vehicle
            L6_3 = L6_3(L7_3)
            if L6_3 then
              goto lbl_74
            end
          end
          L6_3 = false
          ::lbl_74::
          L5_3.doesExist = L6_3
        end
      end
      if L4_3 then
        L5_3 = math
        L5_3 = L5_3.floor
        L6_3 = Threads
        L6_3 = L6_3.Vehicles
        L6_3 = L6_3.RefreshInterval
        L6_3 = L6_3.current
        L5_3 = L5_3(L6_3)
        if L5_3 then
          goto lbl_87
          L1_3 = L5_3 or L1_3
        end
      end
      L1_3 = L0_3
      ::lbl_87::
      if L4_3 then
        L5_3 = Threads
        L5_3 = L5_3.Vehicles
        L5_3 = L5_3.Data
        L5_3 = L5_3.vehicle
        L6_3 = Threads
        L6_3 = L6_3.Vehicles
        L6_3 = L6_3.Data
        L6_3 = L6_3.doesExist
        if L6_3 then
          L6_3 = GetEntitySpeed
          L7_3 = L5_3
          L6_3 = L6_3(L7_3)
          L7_3 = GetVehicleCurrentRpm
          L8_3 = L5_3
          L7_3 = L7_3(L8_3)
          L8_3 = GetGear
          L9_3 = L5_3
          L8_3 = L8_3(L9_3)
          L9_3 = GetFuel
          L10_3 = L5_3
          L9_3 = L9_3(L10_3)
          L10_3 = GetVehicleEngineHealth
          L11_3 = L5_3
          L10_3 = L10_3(L11_3)
          L11_3 = math
          L11_3 = L11_3.floor
          L12_3 = L6_3 * L2_3
          L11_3 = L11_3(L12_3)
          L12_3 = math
          L12_3 = L12_3.floor
          L13_3 = L7_3 * 100
          L12_3 = L12_3(L13_3)
          if 0 == L8_3 then
            L13_3 = "R"
            if L13_3 then
              goto lbl_130
            end
          end
          L13_3 = L8_3
          ::lbl_130::
          L14_3 = L9_3
          L15_3 = L10_3 / 10
          L16_3 = Threads
          L16_3 = L16_3.Vehicles
          L16_3 = L16_3.Data
          L16_3 = L16_3.speed
          if L11_3 ~= L16_3 then
            L16_3 = Threads
            L16_3 = L16_3.Vehicles
            L16_3 = L16_3.Data
            L16_3.speed = L11_3
            L3_3 = true
          else
            L16_3 = Threads
            L16_3 = L16_3.Vehicles
            L16_3 = L16_3.Data
            L16_3 = L16_3.rpm
            if L12_3 ~= L16_3 then
              L16_3 = Threads
              L16_3 = L16_3.Vehicles
              L16_3 = L16_3.Data
              L16_3.rpm = L12_3
              L3_3 = true
            else
              L16_3 = Threads
              L16_3 = L16_3.Vehicles
              L16_3 = L16_3.Data
              L16_3 = L16_3.gear
              if L13_3 ~= L16_3 then
                L16_3 = Threads
                L16_3 = L16_3.Vehicles
                L16_3 = L16_3.Data
                L16_3.gear = L13_3
                L3_3 = true
              else
                L16_3 = Threads
                L16_3 = L16_3.Vehicles
                L16_3 = L16_3.Data
                L16_3 = L16_3.fuel
                if L14_3 ~= L16_3 then
                  L16_3 = Threads
                  L16_3 = L16_3.Vehicles
                  L16_3 = L16_3.Data
                  L16_3.fuel = L14_3
                  L3_3 = true
                else
                  L16_3 = Threads
                  L16_3 = L16_3.Vehicles
                  L16_3 = L16_3.Data
                  L16_3 = L16_3.engine
                  if L15_3 ~= L16_3 then
                    L16_3 = Threads
                    L16_3 = L16_3.Vehicles
                    L16_3 = L16_3.Data
                    L16_3.engine = L15_3
                    L3_3 = true
                  end
                end
              end
            end
          end
          if L3_3 then
            L16_3 = SendNUIMessage
            L17_3 = {}
            L17_3.type = "SET_CARHUD_VALUES"
            L18_3 = {}
            L18_3.speed = L11_3
            L18_3.rpm = L12_3
            L18_3.gear = L13_3
            L18_3.fuel = L14_3
            L18_3.engine = L15_3
            L17_3.data = L18_3
            L16_3(L17_3)
          end
        end
      end
      L5_3 = Storage
      L5_3 = L5_3.CurrentScreen
      L5_3 = GlobalState
      L5_3 = "game" ~= L5_3 or L5_3
      L6_3 = LocalPlayer
      L6_3 = L6_3.state
      L6_3 = L6_3.isInsideVehicle
      if L6_3 then
        L6_3 = LocalPlayer
        L6_3 = L6_3.state
        L6_3 = L6_3.isInsideVehicle
        L6_3 = L6_3.inVeh
        if L6_3 then
          goto lbl_228
        end
      end
      L6_3 = false
      ::lbl_228::
      if L5_3 then
        if L6_3 then
          L7_3 = LocalPlayer
          L7_3 = L7_3.state
          L8_3 = L7_3
          L7_3 = L7_3.set
          L9_3 = "isInsideVehicle"
          L10_3 = {}
          L10_3.inVeh = false
          L10_3.wasInterrupted = true
          L7_3(L8_3, L9_3, L10_3)
          L7_3 = NUI
          L7_3 = L7_3.SendMessage
          L8_3 = "INDICATE_UNFASTEN_SEATBELT"
          L9_3 = {}
          L9_3.state = false
          L7_3(L8_3, L9_3)
        end
      elseif L6_3 ~= L4_3 then
        L7_3 = Config
        L7_3 = L7_3.UseOxLibCache
        if L7_3 then
          L7_3 = Threads
          L7_3 = L7_3.Vehicles
          L7_3 = L7_3.Data
          L8_3 = cache
          L8_3 = L8_3.vehicle
          L7_3.vehicle = L8_3
        else
          L7_3 = Threads
          L7_3 = L7_3.Vehicles
          L7_3 = L7_3.Data
          if L4_3 then
            L8_3 = GetVehiclePedIsIn
            L9_3 = Threads
            L9_3 = L9_3.Players
            L9_3 = L9_3.Data
            L9_3 = L9_3.ped
            L8_3 = L8_3(L9_3)
            if L8_3 then
              goto lbl_276
            end
          end
          L8_3 = 0
          ::lbl_276::
          L7_3.vehicle = L8_3
        end
        L7_3 = Threads
        L7_3 = L7_3.Vehicles
        L7_3 = L7_3.Data
        L7_3 = L7_3.vehicle
        if L7_3 then
          L7_3 = Threads
          L7_3 = L7_3.Vehicles
          L7_3 = L7_3.Data
          L7_3 = L7_3.vehicle
          if 0 ~= L7_3 then
            goto lbl_293
          end
        end
        L7_3 = Threads
        L7_3 = L7_3.Vehicles
        L7_3 = L7_3.Data
        L7_3.doesExist = false
        ::lbl_293::
        L7_3 = LocalPlayer
        L7_3 = L7_3.state
        L8_3 = L7_3
        L7_3 = L7_3.set
        L9_3 = "isInsideVehicle"
        L10_3 = {}
        L10_3.inVeh = L4_3
        L10_3.wasInterrupted = L5_3
        L7_3(L8_3, L9_3, L10_3)
        L7_3 = Library
        L7_3 = L7_3.EventCall
        L8_3 = "onVehicleStateChange"
        L9_3 = Threads
        L9_3 = L9_3.Vehicles
        L9_3 = L9_3.Data
        L9_3 = L9_3.vehicle
        L9_3 = 0 ~= L9_3
        L10_3 = Threads
        L10_3 = L10_3.Vehicles
        L10_3 = L10_3.Data
        L10_3 = L10_3.vehicle
        L7_3(L8_3, L9_3, L10_3)
      end
      L7_3 = Citizen
      L7_3 = L7_3.Wait
      L8_3 = L1_3
      L7_3(L8_3)
    end
  end
  L0_2(L1_2)
end
L0_1.Init = L1_1
L0_1 = Threads
L0_1 = L0_1.Vehicles
function L1_1()
  local L0_2, L1_2
  L0_2 = Config
  L0_2 = L0_2.UI
  L0_2 = L0_2.UseStreetLabel
  if not L0_2 then
    return
  end
  L0_2 = Threads
  L0_2 = L0_2.Vehicles
  L0_2.StreetLabelUse = true
  L0_2 = Citizen
  L0_2 = L0_2.CreateThread
  function L1_2()
    local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3
    L0_3 = Config
    L0_3 = L0_3.Metrics
    if "mph" == L0_3 then
      L0_3 = 0.62
      if L0_3 then
        goto lbl_9
      end
    end
    L0_3 = 1.0
    ::lbl_9::
    L1_3 = GetClockHours
    L1_3 = L1_3()
    L2_3 = GetClockMinutes
    L2_3 = L2_3()
    L3_3 = false
    while true do
      L4_3 = Threads
      L4_3 = L4_3.Vehicles
      L4_3 = L4_3.StreetLabelUse
      if not L4_3 then
        break
      end
      L4_3 = GetClockMinutes
      L4_3 = L4_3()
      L2_3 = L4_3
      if 0 == L2_3 and not L3_3 then
        L4_3 = GetClockHours
        L4_3 = L4_3()
        L1_3 = L4_3
        L3_3 = true
      end
      if L2_3 > 0 and L3_3 then
        L3_3 = false
      end
      L4_3 = Threads
      L4_3 = L4_3.Players
      L4_3 = L4_3.Data
      L4_3 = L4_3.coords
      L5_3 = Threads
      L5_3 = L5_3.Players
      L5_3 = L5_3.Data
      L5_3 = L5_3.heading
      L6_3 = {}
      L7_3 = Threads
      L7_3 = L7_3.Vehicles
      L7_3 = L7_3.DirectionList
      L7_3 = L7_3[L5_3]
      L6_3.direction = L7_3
      L7_3 = GetStreetLabel
      L8_3 = L4_3
      L7_3 = L7_3(L8_3)
      L6_3.streets = L7_3
      L7_3 = string
      L7_3 = L7_3.format
      L8_3 = "%02d:%02d"
      L9_3 = L1_3
      L10_3 = L2_3
      L7_3 = L7_3(L8_3, L9_3, L10_3)
      L6_3.time = L7_3
      L6_3.distance = 0
      L7_3 = IsWaypointActive
      L7_3 = L7_3()
      if L7_3 then
        L7_3 = GetBlipCoords
        L8_3 = GetFirstBlipInfoId
        L9_3 = 8
        L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3 = L8_3(L9_3)
        L7_3 = L7_3(L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3)
        L8_3 = CalculateTravelDistanceBetweenPoints
        L9_3 = L4_3.x
        L10_3 = L4_3.y
        L11_3 = L4_3.z
        L12_3 = L7_3.x
        L13_3 = L7_3.y
        L14_3 = L7_3.z
        L8_3 = L8_3(L9_3, L10_3, L11_3, L12_3, L13_3, L14_3)
        L8_3 = L8_3 / 1000
        L6_3.distance = L8_3
        L8_3 = Config
        L8_3 = L8_3.Metrics
        if "mph" == L8_3 then
          L8_3 = L6_3.distance
          L8_3 = L8_3 * L0_3
          L6_3.distance = L8_3
        end
      end
      L7_3 = StreetLabel
      L7_3 = L7_3.SetStreetLabelData
      L8_3 = L6_3
      L7_3(L8_3)
      L7_3 = Wait
      L8_3 = 550
      L7_3(L8_3)
    end
  end
  L0_2(L1_2)
end
L0_1.StreetLabel = L1_1
L0_1 = AddStateBagChangeHandler
L1_1 = "isInsideVehicle"
L2_1 = nil
function L3_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2
  L3_2 = "player:%s"
  L4_2 = L3_2
  L3_2 = L3_2.format
  L5_2 = GetPlayerServerId
  L6_2 = PlayerId
  L6_2 = L6_2()
  L5_2, L6_2 = L5_2(L6_2)
  L3_2 = L3_2(L4_2, L5_2, L6_2)
  if A0_2 ~= L3_2 then
    return
  end
  L3_2 = Threads
  L3_2 = L3_2.Vehicles
  L3_2 = L3_2.IsRadarVisible
  L4_2 = A2_2.inVeh
  if L3_2 == L4_2 then
    return
  end
  L3_2 = Threads
  L3_2 = L3_2.Vehicles
  L4_2 = A2_2.InVeh
  L3_2.IsRadarVisible = L4_2
  L3_2 = Threads
  L3_2 = L3_2.Vehicles
  L3_2 = L3_2.BlacklistedHashModels
  L4_2 = tostring
  L5_2 = GetEntityModel
  L6_2 = Threads
  L6_2 = L6_2.Vehicles
  L6_2 = L6_2.Data
  L6_2 = L6_2.vehicle
  L5_2, L6_2 = L5_2(L6_2)
  L4_2 = L4_2(L5_2, L6_2)
  L3_2 = L3_2[L4_2]
  if L3_2 then
    A2_2.inVeh = false
  end
  L3_2 = Config
  L3_2 = L3_2.UI
  L3_2 = L3_2.UseStreetLabel
  if L3_2 then
    L3_2 = Config
    L3_2 = L3_2.PersistentStreetLabel
    if not L3_2 then
      L3_2 = A2_2.inVeh
      if L3_2 then
        L3_2 = Threads
        L3_2 = L3_2.Vehicles
        L3_2 = L3_2.StreetLabelUse
        if not L3_2 then
          L3_2 = Threads
          L3_2 = L3_2.Vehicles
          L3_2 = L3_2.StreetLabel
          L3_2()
        end
      else
        L3_2 = Threads
        L3_2 = L3_2.Vehicles
        L3_2.StreetLabelUse = false
      end
      L3_2 = StreetLabel
      L3_2 = L3_2.SetVisible
      L4_2 = A2_2.inVeh
      L3_2(L4_2)
    end
  end
  L3_2 = Config
  L3_2 = L3_2.PersistentMinimap
  if not L3_2 then
    L3_2 = DisplayRadar
    L4_2 = A2_2.inVeh
    L5_2 = A2_2.wasInterrupted
    L3_2(L4_2, L5_2)
  end
  L3_2 = NUI
  L3_2 = L3_2.SendMessage
  L4_2 = "SET_PERSPECTIVE_IN_VEH"
  L5_2 = {}
  L6_2 = A2_2.inVeh
  L5_2.state = L6_2
  L3_2(L4_2, L5_2)
  L3_2 = NUI
  L3_2 = L3_2.SetComponentVisibility
  L4_2 = "carhud"
  L5_2 = A2_2.inVeh
  L3_2(L4_2, L5_2)
end
L0_1(L1_1, L2_1, L3_1)
L0_1 = RegisterNUICallback
L1_1 = "minimap.toggle"
function L2_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2
  L1_2 = DisplayRadar
  L2_2 = A0_2.state
  L3_2 = false
  L1_2(L2_2, L3_2)
  L1_2 = NUI
  L1_2 = L1_2.SendMessage
  L2_2 = "SET_PERSPECTIVE_IN_VEH"
  L3_2 = {}
  L4_2 = A0_2.state
  L3_2.state = L4_2
  L1_2(L2_2, L3_2)
  L1_2 = StreetLabel
  L1_2 = L1_2.SetVisible
  L2_2 = A0_2.state
  L1_2(L2_2)
end
L0_1(L1_1, L2_1)
