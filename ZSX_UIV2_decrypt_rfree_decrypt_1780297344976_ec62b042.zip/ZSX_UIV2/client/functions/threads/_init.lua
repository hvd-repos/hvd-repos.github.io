local L0_1, L1_1
L0_1 = {}
Threads = L0_1
L0_1 = Citizen
L0_1 = L0_1.CreateThread
function L1_1()
  local L0_2, L1_2
  L0_2 = Wait
  L1_2 = 1000
  L0_2(L1_2)
  L0_2 = debugPrint
  L1_2 = "[^6THREADS^7] Awaiting storage to load"
  L0_2(L1_2)
  L0_2 = Threads
  L0_2 = L0_2.Components
  L0_2 = L0_2.Init
  L0_2()
  L0_2 = Threads
  L0_2 = L0_2.Players
  L0_2 = L0_2.Init
  L0_2()
  L0_2 = Threads
  L0_2 = L0_2.GameplayCam
  L0_2 = L0_2.Init
  L0_2()
  while true do
    L0_2 = Storage
    L0_2 = L0_2.Data
    L0_2 = L0_2.createdUI
    if L0_2 then
      break
    end
    L0_2 = Wait
    L1_2 = 0
    L0_2(L1_2)
  end
  L0_2 = Threads
  L0_2 = L0_2.Point
  L0_2 = L0_2.Init
  L0_2()
  L0_2 = Threads
  L0_2 = L0_2.Chat
  L0_2 = L0_2.Init
  L0_2()
  L0_2 = Threads
  L0_2 = L0_2.Vehicles
  L0_2 = L0_2.Init
  L0_2()
  L0_2 = Threads
  L0_2 = L0_2.Weapon
  L0_2 = L0_2.Init
  L0_2()
  L0_2 = Threads
  L0_2 = L0_2.Hud
  L0_2 = L0_2.Init
  L0_2()
  L0_2 = Threads
  L0_2 = L0_2.DUI
  L0_2 = L0_2.Init
  L0_2()
  L0_2 = debugPrint
  L1_2 = "[^6THREADS^7] Loaded"
  L0_2(L1_2)
end
L0_1(L1_1)
