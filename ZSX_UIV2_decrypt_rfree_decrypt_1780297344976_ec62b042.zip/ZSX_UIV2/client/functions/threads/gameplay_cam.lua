local L0_1, L1_1
L0_1 = Threads
L1_1 = {}
L0_1.GameplayCam = L1_1
L0_1 = Threads
L0_1 = L0_1.GameplayCam
L0_1.Id = -1
L0_1 = Threads
L0_1 = L0_1.GameplayCam
function L1_1()
  local L0_2, L1_2
  L0_2 = Citizen
  L0_2 = L0_2.CreateThread
  function L1_2()
    local L0_3, L1_3, L2_3
    L0_3 = 5000
    while true do
      L1_3 = DoesCamExist
      L2_3 = Threads
      L2_3 = L2_3.GameplayCam
      L2_3 = L2_3.Id
      L1_3 = L1_3(L2_3)
      if not L1_3 then
        L1_3 = FindGameplayCameraID
        L1_3()
      end
      L1_3 = Wait
      L2_3 = L0_3
      L1_3(L2_3)
    end
  end
  L0_2(L1_2)
end
L0_1.Init = L1_1
function L0_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2
  L0_2 = GetGameplayCamCoord
  L0_2 = L0_2()
  L1_2 = GetCamCoord
  L2_2 = Threads
  L2_2 = L2_2.GameplayCam
  L2_2 = L2_2.Id
  L1_2 = L1_2(L2_2)
  if L1_2 ~= L0_2 then
    L1_2 = GetCamCoord
    L2_2 = Threads
    L2_2 = L2_2.GameplayCam
    L2_2 = L2_2.Id
    L1_2 = L1_2(L2_2)
    L2_2 = vector3
    L3_2 = 0
    L4_2 = 0
    L5_2 = 0
    L2_2 = L2_2(L3_2, L4_2, L5_2)
    if L1_2 == L2_2 then
      goto lbl_23
    end
  end
  do return end
  ::lbl_23::
  L1_2 = 1
  L2_2 = 10000
  L3_2 = 1
  for L4_2 = L1_2, L2_2, L3_2 do
    L5_2 = DoesCamExist
    L6_2 = L4_2
    L5_2 = L5_2(L6_2)
    if L5_2 then
      L5_2 = GetCamCoord
      L6_2 = L4_2
      L5_2 = L5_2(L6_2)
      if L5_2 == L0_2 then
        L5_2 = Threads
        L5_2 = L5_2.GameplayCam
        L5_2.Id = L4_2
        L5_2 = debugPrint
        L6_2 = "[^4CAMERA^7] Restored Gameplay Camera ID."
        L5_2(L6_2)
        break
      end
    end
  end
end
FindGameplayCameraID = L0_1
function L0_1()
  local L0_2, L1_2
  L0_2 = Threads
  L0_2 = L0_2.GameplayCam
  L0_2 = L0_2.Id
  return L0_2
end
GetGameplayCameraID = L0_1
