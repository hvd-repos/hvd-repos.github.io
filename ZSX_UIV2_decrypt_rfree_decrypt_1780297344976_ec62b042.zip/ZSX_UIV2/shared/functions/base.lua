local L0_1, L1_1
function L0_1(A0_2)
  local L1_2, L2_2, L3_2
  L1_2 = Config
  L1_2 = L1_2.Debug
  if not L1_2 then
    return
  end
  L1_2 = print
  L2_2 = "^5[INTERFACE] ^7"
  L3_2 = A0_2
  L2_2 = L2_2 .. L3_2
  L1_2(L2_2)
end
debugPrint = L0_1
L0_1 = {}
_Lib = L0_1
L0_1 = _Lib
function L1_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2
  L1_2 = {}
  L2_2 = 1
  L3_2 = A0_2
  L4_2 = 1
  for L5_2 = L2_2, L3_2, L4_2 do
    L6_2 = math
    L6_2 = L6_2.random
    L7_2 = 1
    L8_2 = 2
    L6_2 = L6_2(L7_2, L8_2)
    L7_2 = nil
    if 1 == L6_2 then
      L8_2 = string
      L8_2 = L8_2.char
      L9_2 = math
      L9_2 = L9_2.random
      L10_2 = 65
      L11_2 = 90
      L9_2, L10_2, L11_2 = L9_2(L10_2, L11_2)
      L8_2 = L8_2(L9_2, L10_2, L11_2)
      L7_2 = L8_2
    else
      L8_2 = tostring
      L9_2 = math
      L9_2 = L9_2.random
      L10_2 = 0
      L11_2 = 9
      L9_2, L10_2, L11_2 = L9_2(L10_2, L11_2)
      L8_2 = L8_2(L9_2, L10_2, L11_2)
      L7_2 = L8_2
    end
    L8_2 = table
    L8_2 = L8_2.insert
    L9_2 = L1_2
    L10_2 = L7_2
    L8_2(L9_2, L10_2)
  end
  L2_2 = table
  L2_2 = L2_2.concat
  L3_2 = L1_2
  return L2_2(L3_2)
end
L0_1.GenerateRandomString = L1_1
L0_1 = _Lib
function L1_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2
  L1_2 = ""
  L2_2 = ipairs
  L3_2 = A0_2
  L2_2, L3_2, L4_2, L5_2 = L2_2(L3_2)
  for L6_2, L7_2 in L2_2, L3_2, L4_2, L5_2 do
    L8_2 = L1_2
    L9_2 = " "
    L10_2 = L7_2
    L8_2 = L8_2 .. L9_2 .. L10_2
    L1_2 = L8_2
  end
  return L1_2
end
L0_1.ConvertArgumentsToString = L1_1
