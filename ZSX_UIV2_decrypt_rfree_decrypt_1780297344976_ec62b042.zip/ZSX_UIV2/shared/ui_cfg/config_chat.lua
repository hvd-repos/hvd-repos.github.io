Config.Chat = {}
Config.Chat.Use = true
Config.Chat.Icons = {
    ['me'] = 'ME',
    ['do'] = 'DO',
    ['ooc'] = 'OOC',
    ['twt'] = 'fas fa-twitter',
}

Config.Chat.AllowUserChangeSize = true              -- [BOOL] [DEF. true] Allow users to change chat size.
Config.Chat.Size = 'medium'                          -- [STRING] [DEF. 'small'] Default chat size. 
                                                    --[[                        Supported sizes:
                                                                                    'small'
                                                                                    'medium'
                                                                                    'big'
                                                    ]]

Config.Chat.Translate = {
    ['player_with_id'] = 'Player with ID',
    ['enter_message'] = 'Enter command/message'
}

Config.Chat.UseCommandsWithoutSyntax = true        -- [BOOL] [DEF. false] Allow to use commands without "/" syntax.

Config.Chat.MaxPoolSize = false                     -- [BOOL/NUMBER] [DEF. false] If you'd like to prevent high GPU usage for rendering not used messages, we suggest applying some kind of maximal pool size for messages
                                                    -- Example with max messages set to 30
                                                    -- Config.Chat.MaxPoolSize = 30
